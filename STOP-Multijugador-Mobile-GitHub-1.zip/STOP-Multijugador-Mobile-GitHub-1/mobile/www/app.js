const SERVER = "https://stop-multijugador-server-production.up.railway.app";
const socket = io(SERVER, { transports: ["websocket","polling"], reconnection: true, timeout: 10000 });

const $ = id => document.getElementById(id);
const screens = ["home","lobby","game","results"];
let room = null;
let categories = [];
let endsAt = null;
let tick = null;
let submitTimer = null;

function show(id){ screens.forEach(x => $(x).classList.toggle("hidden", x!==id)); }
function msg(id,text=""){ $(id).textContent=text; }
function ack(event,payload){ return new Promise(resolve => socket.emit(event,payload,resolve)); }

socket.on("connect",()=>{ $("conn").textContent="En línea"; $("conn").className="pill online"; });
socket.on("disconnect",()=>{ $("conn").textContent="Sin conexión"; $("conn").className="pill offline"; });

$("create").onclick = async()=>{
  msg("homeMsg"); const name=$("name").value.trim();
  const r=await ack("room:create",{name});
  if(!r?.ok) return msg("homeMsg",r?.error||"No se pudo crear la sala");
};

$("join").onclick = async()=>{
  msg("homeMsg"); const name=$("name").value.trim(); const code=$("code").value.trim();
  const r=await ack("room:join",{name,code});
  if(!r?.ok) return msg("homeMsg",r?.error||"No se pudo entrar");
};

$("start").onclick = async()=>{
  msg("lobbyMsg"); const r=await ack("round:start",{});
  if(!r?.ok) msg("lobbyMsg",r?.error||"No se pudo iniciar");
};

$("next").onclick = async()=>{
  const r=await ack("round:start",{});
  if(!r?.ok) alert(r?.error||"No se pudo iniciar");
};

$("share").onclick = async()=>{
  const text="Únete a mi sala de STOP. Código: "+(room?.code||"");
  try{
    if(navigator.share) await navigator.share({title:"STOP Multijugador",text});
    else { await navigator.clipboard.writeText(text); alert("Código copiado"); }
  }catch{}
};

$("stop").onclick = async()=>{
  $("stop").disabled=true;
  const r=await ack("round:stop",{answers:getAnswers()});
  if(!r?.ok){ $("stop").disabled=false; msg("gameMsg",r?.error||"No se pudo detener"); }
};

socket.on("room:update", r=>{
  room=r;
  $("roomCode").textContent=r.code;
  $("count").textContent="("+r.players.length+"/10)";
  $("players").innerHTML=r.players.map(p=>`<div class="player"><span>${escapeHtml(p.name)}</span><span>${p.id===r.hostId?'<span class="hostTag">ANFITRIÓN</span>':p.total+" pts"}</span></div>`).join("");
  const host = socket.id===r.hostId;
  $("start").classList.toggle("hidden",!host);
  $("next").classList.toggle("hidden",!host);
  if(r.phase==="lobby") show("lobby");
});

socket.on("round:start", data=>{
  categories=data.categories||[]; endsAt=data.endsAt;
  $("roundNum").textContent=data.round; $("letter").textContent=data.letter;
  $("fields").innerHTML=categories.map((c,i)=>`<div class="field"><label>${escapeHtml(c)}</label><input id="a${i}" data-cat="${escapeAttr(c)}" autocomplete="off" autocapitalize="words" /></div>`).join("");
  $("stop").disabled=false; msg("gameMsg"); show("game");
  document.querySelectorAll("#fields input").forEach(el=>el.addEventListener("input", scheduleSubmit));
  startTimer();
});

socket.on("round:results", data=>{
  clearInterval(tick); tick=null; clearTimeout(submitTimer);
  $("resultLetter").textContent=data.letter;
  const sorted=[...data.rows].sort((a,b)=>b.total-a.total);
  const max=sorted[0]?.total??0;
  $("scoreboard").innerHTML=sorted.map(row=>`
    <div class="scoreCard ${row.total===max?'winner':''}">
      <div class="scoreTop"><span class="scoreName">${escapeHtml(row.name)}</span><span class="scoreTotal">${row.roundTotal} esta ronda · ${row.total} total</span></div>
      <div class="answers">
        ${data.categories.map(c=>`<div class="answerRow"><span>${escapeHtml(c)}</span><span>${escapeHtml(row.answers[c]||"—")}</span><span class="pts">+${row.points[c]||0}</span></div>`).join("")}
      </div>
    </div>`).join("");
  $("next").classList.toggle("hidden", socket.id!==room?.hostId);
  show("results");
});

function getAnswers(){
  const out={};
  document.querySelectorAll("#fields input").forEach(el=>out[el.dataset.cat]=el.value.trim());
  return out;
}
function scheduleSubmit(){
  clearTimeout(submitTimer);
  submitTimer=setTimeout(()=>socket.emit("answers:submit",{answers:getAnswers()},()=>{}),250);
}
function startTimer(){
  clearInterval(tick);
  const draw=()=>{
    const left=Math.max(0,Math.ceil((endsAt-Date.now())/1000));
    $("timer").textContent=left;
    if(left<=0){ clearInterval(tick); tick=null; socket.emit("answers:submit",{answers:getAnswers()},()=>{}); }
  };
  draw(); tick=setInterval(draw,250);
}
function escapeHtml(s){ return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c])); }
function escapeAttr(s){ return escapeHtml(s).replace(/\n/g," "); }
