STOP Multijugador Mobile
=========================
Este paquete contiene la app móvil conectada al servidor Railway y un workflow de GitHub Actions para generar un APK Android.

Servidor:
https://stop-multijugador-server-production.up.railway.app
